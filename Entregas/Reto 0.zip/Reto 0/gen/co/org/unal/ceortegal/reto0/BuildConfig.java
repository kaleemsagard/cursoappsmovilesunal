/** Automatically generated file. DO NOT MODIFY */
package co.org.unal.ceortegal.reto0;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}